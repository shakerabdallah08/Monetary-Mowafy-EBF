package org.mokhtar.foodbank;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.*;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private static final int REQ_FILE = 11;
    private WebView printer; // keeps the print WebView alive

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage: where all the data lives
        s.setAllowFileAccess(false);   // assets (file:///android_asset) stay accessible
        s.setSupportZoom(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(p.createIntent(), REQ_FILE); }
                catch (Exception e) { chooser = null; return false; }
                return true;
            }
            @Override public boolean onJsAlert(WebView v, String u, String m, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(m)
                        .setPositiveButton("حسنًا", (d, i) -> r.confirm()).setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String u, String m, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(m)
                        .setPositiveButton("موافق", (d, i) -> r.confirm())
                        .setNegativeButton("إلغاء", (d, i) -> r.cancel()).setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView v, String u, String m, String def, JsPromptResult r) {
                final EditText et = new EditText(MainActivity.this); et.setText(def);
                new AlertDialog.Builder(MainActivity.this).setMessage(m).setView(et)
                        .setPositiveButton("موافق", (d, i) -> r.confirm(et.getText().toString()))
                        .setNegativeButton("إلغاء", (d, i) -> r.cancel()).setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        // inside the app: "back" button visible -> go to previous screen, otherwise leave
        web.evaluateJavascript("(function(){var b=document.getElementById('back');" +
                "if(b&&b.style.display!='none'&&b.offsetParent!==null){b.click();return 1}return 0})()", v -> {
            if (!"1".equals(v)) MainActivity.super.onBackPressed();
        });
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == REQ_FILE && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
            chooser = null;
        } else super.onActivityResult(rq, rs, d);
    }

    class Bridge {
        @JavascriptInterface public void saveFile(String name, String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                String clean = name.replaceAll("[\\\\/:*?\"<>|]", "-");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, clean);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/المختار");
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(data); }
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "المختار");
                    dir.mkdirs();
                    try (FileOutputStream o = new FileOutputStream(new File(dir, clean))) { o.write(data); }
                }
                toast("تم الحفظ في التنزيلات/المختار: " + clean);
            } catch (Exception e) { toast("تعذر الحفظ: " + e.getMessage()); }
        }
        @JavascriptInterface public void printHtml(String html, String title) {
            runOnUiThread(() -> {
                printer = new WebView(MainActivity.this);
                printer.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView v, String url) {
                        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                        pm.print(title, v.createPrintDocumentAdapter(title), new PrintAttributes.Builder().build());
                    }
                });
                printer.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
            });
        }
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                pm.print("تقرير", web.createPrintDocumentAdapter("تقرير"), new PrintAttributes.Builder().build());
            });
        }
    }

    private void toast(String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }
}
